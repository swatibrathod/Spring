package org.qspider.courseapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
